from service.logger.logger import get_logger

from utils.eu_utils.eu_pydantic import execute_lang_chain, pydantic_llm_instance
from utils.eu_pdf_utils.eu_pdf_prompts import extractor_system_prompt, extractor_system_prompt_3_7, Result

from utils.eu_utils.eu_common_utils import max_tokens
from utils.eu_utils.eu_name_aliases_utils import permute_names, adjust_for_names
from utils.eu_utils.eu_name_engine_v2_utils import run_name_engine_v2_pipeline
from utils.eu_utils.edge_case.ec_engine import apply_edge_case_gate

from langchain_core.output_parsers import JsonOutputParser
import asyncio, re
logger = get_logger("eu_pdf_data_point_extractor_utils")


entry_parser = JsonOutputParser(pydantic_object=Result)
output_format_records = entry_parser.get_format_instructions()
validation_method_entries = "Entries"

def get_name_adjusted_records(temp_output_list):
    try:
        if not temp_output_list:
            return []
        temp_output_list = adjust_for_names(temp_output_list)
        temp_output_list = permute_names(temp_output_list)
        
        try:
            raw_names = []
            for item in temp_output_list:
                if isinstance(item, dict) and "name" in item:
                    raw_names.append(item.get("name"))
                elif isinstance(item, dict) and "primary_name" in item:
                    raw_names.append(item.get("primary_name"))
            if raw_names:
                run_name_engine_v2_pipeline(raw_names, [])
        except Exception as v2_err:
            logger.error(f"Error triggering Name Engine V2: {v2_err}")
            
        logger.info(f"Total number of entries in this content: {len(temp_output_list)}")
        temp_output_list = apply_edge_case_gate(temp_output_list)  # ← edge case gate (parallel, additive)
        return temp_output_list              
    except Exception as e:
        logger.error(f"Error occurred while get_name_adjusted_records: {e} for input {temp_output_list}")
        return []
    
def extract_complete_records(output_message,costs): #todo name change
    extract_content_again = True
    list_of_records_in_content = []
    try:
        if costs.completion_tokens < max_tokens:
            logger.info("LLM has stoped gracefully")
            list_of_records_in_content.extend(get_name_adjusted_records(output_message.get("result",[])))
            extract_content_again = False
        else:
            logger.info("LLM has stoped unexpectedly")
            logger.info(output_message)
            list_of_records_in_content.extend(get_name_adjusted_records(output_message.get("result",[])[:-1]))
        return list_of_records_in_content, extract_content_again
    except Exception as E:
        logger.error(f"Error occurred while extract_complete_records: {E}, costs: {costs}, llm_response: {output_message}")

def modify_llm_output(output_message):
    for entry in output_message.get("result"):
        entry["name_info"] = re.sub(r'(\\n|\n)', ' ', entry["name_info"])
    return output_message

def process_content(input_content_for_LLM_call):
    list_of_records_in_content= []
    should_extract_content = True
    try:
        while(should_extract_content == True):
            last_entity = list_of_records_in_content[-1] if list_of_records_in_content else ""
            prompt_for_call = extractor_system_prompt if not last_entity else extractor_system_prompt_3_7
            input_for_call = f"*Input*: {input_content_for_LLM_call}" if not last_entity else f"""*Input*: {input_content_for_LLM_call}\n*Last Entity*: {last_entity.get("name", "")}"""

            output_message,costs = execute_lang_chain(system_prompt=prompt_for_call, 
                                                    format_instructions=output_format_records,
                                                    input_content=input_for_call, 
                                                    parser=entry_parser,
                                                    model=pydantic_llm_instance,
                                                    validation_method=validation_method_entries
                                                    )
            logger.info(f"LLM output: {output_message}, costs: {costs}")
            output_message = modify_llm_output(output_message)
            records_extracted, should_extract_content = extract_complete_records(output_message, costs)
            list_of_records_in_content.extend(records_extracted)
    except Exception as E:
        logger.error(f"Error in process_content for content: {input_content_for_LLM_call} as error: {E}")
    
    if isinstance(input_content_for_LLM_call, list):
        for item in list_of_records_in_content:
            item["completeInformation"] = str(input_content_for_LLM_call)    
    
    return list_of_records_in_content

async def parallelized_processing(contents):
    logger.info("Parallel Extraction of Records has begun")
    individuals_data_full = []
    # Use asyncio.to_thread to run blocking tasks in parallel
    tasks = [asyncio.to_thread(process_content, content) for content in contents]
    
    # Gather results concurrently
    results = await asyncio.gather(*tasks)
    
    # Collect all individual results
    for individuals_data in results:
        individuals_data_full.extend(individuals_data)

    final_output_list = individuals_data_full
    return final_output_list