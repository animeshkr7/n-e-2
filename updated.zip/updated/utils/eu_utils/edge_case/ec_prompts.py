"""
ec_prompts.py
--------------
LLM prompt for the new HITL-driven edge case flow.

The prompt receives:
  - complex_name : the raw, complex sanctioned entity name string (main input to process)
  - primary_name : the clean primary name for this entity
  - context      : all extracted entity context (dict or str from the PR)
  - similar_edge_cases : list of top-X reference matches from ec_similarity_search
                         [{"key": str, "value": [str, ...], "score": float}, ...]

The LLM is asked to generate all possible P&C name variations using the edge cases
as grounding examples.

Expected LLM output (JSON) — matches main flow output keys exactly:
{
    "aliases":     ["Name1", "Name2", ...],  # Latin-script variations  (= main flow aliases)
    "aliases_og":  ["اسم1", "اسم2", ...],   # Non-Latin variations     (= main flow aliases_og)
    "reasoning":   "brief explanation"       # optional, for debugging
}
"""

import json
from service.logger.logger import get_logger

logger = get_logger("ec_prompts")


def _format_similar_cases(similar_edge_cases: list[dict]) -> str:
    """
    Format the top-X similar reference cases into a readable block for the prompt.

    Each case shows:
        INPUT  (primary name) → OUTPUTS (verified aliases / P&C combinations)
    """
    if not similar_edge_cases:
        return "  (No similar edge cases found in reference file — rely on your own judgment.)"

    lines = []
    for i, case in enumerate(similar_edge_cases, start=1):
        key = case.get("key", "")
        values = case.get("value", [])
        score = case.get("score", 0.0)
        formatted_values = "\n    ".join(f'"{v}"' for v in values)
        lines.append(
            f"  Case {i} (similarity score: {score:.2f}):\n"
            f"    INPUT  : \"{key}\"\n"
            f"    OUTPUTS:\n    {formatted_values}"
        )

    return "\n\n".join(lines)


def edge_case_generation_prompt(
    complex_name: str,
    primary_name: str,
    context: dict | str,
    similar_edge_cases: list[dict],
) -> list[dict]:
    """
    Build the LLM messages list for the edge case name variation generation.

    Args:
        complex_name:       The raw complex sanctioned entity name string.
        primary_name:       The clean primary name of the entity.
        context:            Full entity context dict (or str) from the press release.
        similar_edge_cases: Top-X similar entries from the reference file.

    Returns:
        List of OpenAI-style chat messages [{"role": ..., "content": ...}].
    """
    # Serialize context safely
    if isinstance(context, dict):
        context_str = json.dumps(context, ensure_ascii=False, indent=2)
    else:
        context_str = str(context)

    similar_cases_block = _format_similar_cases(similar_edge_cases)

    prompt = f"""You are an expert in sanctions compliance and multilingual name analysis.

Your task is to analyze a complex sanctioned entity name and generate EVERY possible
name variation (permutations and combinations) that this entity could be referred to,
across all scripts (Latin, Arabic, Cyrillic, etc.).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INPUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[COMPLEX SANCTIONED NAME]  ← This is the PRIMARY thing to process.
{complex_name}

[PRIMARY NAME]
{primary_name}

[ENTITY CONTEXT]
{context_str}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SIMILAR EDGE CASES FROM REFERENCE  ← Use these as grounding examples.
Each shows how a similar complex name was correctly processed before.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{similar_cases_block}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INSTRUCTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Parse the COMPLEX SANCTIONED NAME carefully.
   - Extract all first name aliases, last name aliases, and any standalone full name variants
     (e.g. names in Arabic/Cyrillic brackets that are completely separate names).
   - Use the similar edge cases as a style guide for how to interpret ambiguous formatting.

2. Perform ALL possible Permutations & Combinations (P&C):
   - Cross every first-name alias with every last-name alias.
   - Include all standalone full name variants directly (do NOT break them up).
   - Include middle name variants where applicable.
   - Do NOT include empty or nonsensical combinations.

3. Separate the results into EXACTLY two lists — use these exact key names:
   - "aliases"    : names written purely in Latin script (Roman alphabet).
   - "aliases_og" : names written in any non-Latin script (Arabic, Cyrillic, Persian, etc.).
   These two keys are the ONLY name lists in your output. Do NOT create any other name lists.

4. Include a brief reasoning field explaining how you interpreted the complex name.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OUTPUT FORMAT  — Return ONLY valid JSON, no markdown, no extra text.
Use EXACTLY these key names to match the downstream pipeline.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{{
  "aliases":    ["<latin_name1>", "<latin_name2>", ...],
  "aliases_og": ["<arabic_name1>", "<cyrillic_name1>", ...],
  "reasoning":  "<brief explanation of how you parsed the complex name>"
}}
"""

    messages = [
        {
            "role": "user",
            "content": prompt,
        }
    ]

    logger.info(
        f"edge_case_generation_prompt built for primary_name='{primary_name}', "
        f"similar_cases={len(similar_edge_cases)}"
    )

    return messages
