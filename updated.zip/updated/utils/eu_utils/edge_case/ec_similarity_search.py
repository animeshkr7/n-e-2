"""
ec_similarity_search.py
------------------------
Similarity search: finds the top-X most similar keys from the reference dict
relative to the input primary_name.

Reuses the difflib.SequenceMatcher approach already established in
eu_name_engine_v2_utils.py — no new dependencies.

Usage:
    from utils.eu_utils.edge_case.ec_similarity_search import find_top_x_similar
    results = find_top_x_similar("Vladimir PLAHOTNIUC", reference_dict, top_x=5)
    # returns list of {"key": str, "value": list[str], "score": float}
"""

import difflib
from service.logger.logger import get_logger

logger = get_logger("ec_similarity_search")

# ── Configurable defaults ──────────────────────────────────────────────────────
DEFAULT_TOP_X: int = 5          # How many reference examples to retrieve
SIMILARITY_THRESHOLD: float = 0.0  # Minimum score to include; 0.0 = include all (sorted)


def find_top_x_similar(
    primary_name: str,
    reference_dict: dict,
    top_x: int = DEFAULT_TOP_X,
    threshold: float = SIMILARITY_THRESHOLD,
) -> list[dict]:
    """
    Compute fuzzy similarity between `primary_name` and every key in
    `reference_dict`, then return the top-X closest matches.

    Args:
        primary_name:    The clean primary name of the current entity.
        reference_dict:  Loaded reference dict { primary_name: [aliases...] }.
        top_x:           Number of top matches to return (configurable; default 5).
        threshold:       Minimum SequenceMatcher ratio to include a key.
                         Set to 0.0 to always return top_x regardless of score.

    Returns:
        List of dicts (sorted best-first):
        [
            {
                "key":   "<matched reference primary name>",
                "value": ["alias1", "alias2", ...],
                "score": 0.85
            },
            ...
        ]
        Empty list if reference_dict is empty or no matches exceed threshold.
    """
    if not primary_name or not reference_dict:
        logger.info("find_top_x_similar: empty primary_name or reference_dict — returning []")
        return []

    scored: list[dict] = []

    for ref_key, ref_value in reference_dict.items():
        score = difflib.SequenceMatcher(
            None,
            primary_name.strip().lower(),
            ref_key.strip().lower()
        ).ratio()

        if score >= threshold:
            scored.append({
                "key":   ref_key,
                "value": ref_value if isinstance(ref_value, list) else [ref_value],
                "score": round(score, 4),
            })

    # Sort descending by score
    scored.sort(key=lambda x: x["score"], reverse=True)

    top_results = scored[:top_x]

    logger.info(
        f"Similarity search for '{primary_name}': "
        f"searched {len(reference_dict)} keys, "
        f"returning top {len(top_results)} (top_x={top_x})."
    )
    for r in top_results:
        logger.info(f"  score={r['score']:.4f}  key='{r['key']}'")

    return top_results
