"""
test_pdf_full_flow.py
---------------------
Runs a local EU PDF file through the FULL main extraction pipeline,
including the new edge case gate, and prints the results.

Usage (from project root):
    python utils/eu_utils/edge_case/test_pdf_full_flow.py --pdf path/to/document.pdf

Optional flags:
    --out  path/to/output.json   Save full results to a JSON file (default: test_pdf_output.json
                                  in the same folder as this script)

Requirements:
    - OPENAI_API_KEY must be set in .env (used by both the main extractor and edge case engine)
    - The PDF file must be a valid EU sanctions press release

Example:
    python utils/eu_utils/edge_case/test_pdf_full_flow.py --pdf constants/sample_eu_doc.pdf
"""

import os
import sys
import json
import argparse

# ── Make project root importable ──────────────────────────────────────────────
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir    = os.path.normpath(os.path.join(current_dir, "..", "..", ".."))
sys.path.insert(0, root_dir)

# ── Argument parsing ──────────────────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Run a PDF through the full EU extraction pipeline.")
parser.add_argument("--pdf", required=True, help="Path to the EU sanctions PDF file.")
parser.add_argument(
    "--out",
    default=os.path.join(current_dir, "test_pdf_output.json"),
    help="Path to save the JSON output (default: test_pdf_output.json next to this script).",
)
args = parser.parse_args()

if not os.path.isfile(args.pdf):
    print(f"ERROR: PDF file not found: {args.pdf}")
    sys.exit(1)

# ── Load env + config ─────────────────────────────────────────────────────────
from config.config import Config
if not Config.OPENAI_API_KEY:
    print("ERROR: OPENAI_API_KEY is not set. Add it to your .env file.")
    sys.exit(1)

import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(name)s | %(message)s")

# ── Run full pipeline ─────────────────────────────────────────────────────────
from service.extractor.eu_extractor.eu_pdf_extractor import pdf_extractor

print(f"\n>>> Reading PDF: {args.pdf}")
with open(args.pdf, "rb") as fh:
    pdf_bytes = fh.read()

print(">>> Starting full extraction pipeline (this includes edge case gate)...\n")
records, _, _, _, _, _ = pdf_extractor(pdf_bytes)

# ── Print summary ─────────────────────────────────────────────────────────────
print(f"\n{'='*70}")
print(f"  EXTRACTION COMPLETE — {len(records)} entities extracted")
print(f"{'='*70}")

for i, entity in enumerate(records, 1):
    name         = entity.get("name", "?")
    aliases      = entity.get("aliases", [])
    aliases_og   = entity.get("aliases_og", [])
    print(f"\n  [{i}] {name}")
    print(f"       aliases     ({len(aliases)}): {aliases[:5]}{'...' if len(aliases) > 5 else ''}")
    print(f"       aliases_og  ({len(aliases_og)}): {aliases_og[:5]}{'...' if len(aliases_og) > 5 else ''}")

# ── Save output ───────────────────────────────────────────────────────────────
with open(args.out, "w", encoding="utf-8") as fh:
    json.dump(records, fh, ensure_ascii=False, indent=2)

print(f"\n>>> Full output saved to: {args.out}")
