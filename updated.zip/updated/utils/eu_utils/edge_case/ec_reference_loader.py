"""
ec_reference_loader.py
-----------------------
Loads and caches the HITL-curated edge case reference file.

Reference file format (JSON):
{
    "<primary_name>": [<verified_alias_1>, <verified_alias_2>, ...]
}

Keys   = Primary names of known edge case entities (provided by HITL as input).
Values = Verified, P&C-done, extracted name combinations and aliases for that entity.

Usage:
    from utils.eu_utils.edge_case.ec_reference_loader import load_reference_file
    ref = load_reference_file()       # loads from default path
    ref = load_reference_file(path)   # or a custom path
"""

import json
import os
from service.logger.logger import get_logger

logger = get_logger("ec_reference_loader")

# ── Default path: constants/edge_case_reference.json ──────────────────────────
_DEFAULT_REFERENCE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),   # .../utils/eu_utils/edge_case/
    "..", "..", "..",                              # up to project root
    "constants",
    "edge_case_reference.json"
)
_DEFAULT_REFERENCE_PATH = os.path.normpath(_DEFAULT_REFERENCE_PATH)

# ── In-memory cache so the file is read only once per process ─────────────────
_REFERENCE_CACHE: dict | None = None


def load_reference_file(path: str = _DEFAULT_REFERENCE_PATH) -> dict:
    """
    Load the edge-case reference JSON file.

    The result is cached after the first successful read so subsequent calls
    within the same process are instant (no repeated disk I/O).

    Args:
        path: Absolute or relative path to the reference JSON file.
              Defaults to constants/edge_case_reference.json.

    Returns:
        dict  { primary_name (str): [alias1, alias2, ...] }
        Empty dict if the file is missing or malformed.
    """
    global _REFERENCE_CACHE

    if _REFERENCE_CACHE is not None:
        return _REFERENCE_CACHE

    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)

        if not isinstance(data, dict):
            logger.error(
                f"Reference file at '{path}' is not a JSON object (dict). "
                f"Got: {type(data)}. Returning empty reference."
            )
            _REFERENCE_CACHE = {}
        else:
            logger.info(
                f"Edge case reference file loaded from '{path}'. "
                f"Total keys: {len(data)}"
            )
            _REFERENCE_CACHE = data

    except FileNotFoundError:
        logger.warning(
            f"Edge case reference file not found at '{path}'. "
            "Returning empty reference — similarity search will yield no results."
        )
        _REFERENCE_CACHE = {}
    except json.JSONDecodeError as exc:
        logger.error(
            f"Failed to parse reference file at '{path}': {exc}. "
            "Returning empty reference."
        )
        _REFERENCE_CACHE = {}

    return _REFERENCE_CACHE


def reload_reference_file(path: str = _DEFAULT_REFERENCE_PATH) -> dict:
    """
    Force-reload the reference file (bypasses cache).
    Useful when the reference file is updated during a long-running process.
    """
    global _REFERENCE_CACHE
    _REFERENCE_CACHE = None
    return load_reference_file(path)
