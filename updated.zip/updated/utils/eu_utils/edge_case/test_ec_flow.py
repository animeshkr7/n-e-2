"""
test_ec_flow.py
----------------
Test script for the new HITL-driven edge case flow.

Reads from sample_hitl_inputs.json and runs each case through
the ec_engine, logging results to stdout.

Usage (from project root):
    python utils/eu_utils/edge_case/test_ec_flow.py

Optional: override the LLM provider to Groq by setting GROQ_API_KEY
and passing --groq flag.

    $env:GROQ_API_KEY = "your_key"
    python utils/eu_utils/edge_case/test_ec_flow.py --groq
"""

import os
import sys
import json
import argparse
import logging

# ── Make project root importable ──────────────────────────────────────────────
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.normpath(os.path.join(current_dir, "..", "..", ".."))
sys.path.insert(0, root_dir)

# ── Argument parsing ──────────────────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Test the HITL edge case flow.")
parser.add_argument(
    "--groq",
    action="store_true",
    help="Use Groq (llama-3.1-8b-instant) instead of OpenAI — requires GROQ_API_KEY.",
)
parser.add_argument(
    "--case",
    type=str,
    default=None,
    help="Run a specific case by _case_id (e.g. EC-001). Runs all if not set.",
)
parser.add_argument(
    "--parallel",
    action="store_true",
    help="Run the flow in parallel (background thread) and wait for result.",
)
args = parser.parse_args()

# ── LLM provider setup ────────────────────────────────────────────────────────
if args.groq:
    groq_key = os.environ.get("GROQ_API_KEY")
    if not groq_key:
        print("ERROR: --groq requires GROQ_API_KEY environment variable.")
        sys.exit(1)

    from openai import OpenAI
    import utils.eu_utils.eu_common_utils as eu_common_utils

    groq_client = OpenAI(api_key=groq_key, base_url="https://api.groq.com/openai/v1")
    eu_common_utils.client = groq_client
    eu_common_utils.max_tokens = 8192  # Groq needs more room for full JSON output

    _original_llm_call = eu_common_utils.llm_call_open_ai
    def _groq_llm_call(message, model=None):
        return _original_llm_call(message, model="llama-3.3-70b-versatile")
    eu_common_utils.llm_call_open_ai = _groq_llm_call

    print(">>> LLM Provider: Groq (llama-3.3-70b-versatile)")
else:
    from config.config import Config
    if not Config.OPENAI_API_KEY:
        print("ERROR: OPENAI_API_KEY is not set in your .env / environment.")
        sys.exit(1)
    print(">>> LLM Provider: OpenAI (gpt-4.1 via llm_for_pydantic)")

# ── Load engine after patching ────────────────────────────────────────────────
from utils.eu_utils.edge_case.ec_engine import (
    run_edge_case_flow,
    run_edge_case_flow_parallel,
    TOP_X,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(name)s | %(message)s")

# ── Load sample HITL inputs (lives in constants/ at the project root) ────────
HITL_INPUTS_PATH = os.path.normpath(
    os.path.join(current_dir, "..", "..", "..", "constants", "sample_hitl_inputs.json")
)
with open(HITL_INPUTS_PATH, "r", encoding="utf-8") as fh:
    hitl_data = json.load(fh)

all_cases = hitl_data.get("hitl_edge_case_inputs", [])

# Filter by --case if provided
if args.case:
    all_cases = [c for c in all_cases if c.get("_case_id") == args.case]
    if not all_cases:
        print(f"ERROR: No case found with _case_id='{args.case}'")
        sys.exit(1)


def print_separator(title=""):
    print("\n" + "=" * 70)
    if title:
        print(f"  {title}")
        print("=" * 70)


def run_single_case(case: dict):
    case_id      = case.get("_case_id", "?")
    note         = case.get("_note", "")
    complex_name = case["complex_name"]
    primary_name = case["primary_name"]
    context      = case["context"]

    print_separator(f"CASE {case_id}: {note}")
    print(f"  Complex Name : {complex_name}")
    print(f"  Primary Name : {primary_name}")
    print(f"  TOP_X        : {TOP_X}")

    if args.parallel:
        print("\n  [Running in PARALLEL mode — firing background thread...]")
        future = run_edge_case_flow_parallel(complex_name, primary_name, context)
        print("  [Main thread continues... waiting for result now]")
        result = future.result(timeout=180)
    else:
        result = run_edge_case_flow(complex_name, primary_name, context)

    print(f"\n  Error         : {result.get('error')}")
    print(f"  Reasoning     : {result.get('reasoning', '')[:200]}")
    print(f"\n  Similar Cases Used ({len(result.get('similar_cases_used', []))}):")
    for sc in result.get("similar_cases_used", []):
        print(f"    score={sc['score']:.4f}  key='{sc['key']}'")

    aliases     = result.get("aliases", [])
    aliases_og  = result.get("aliases_og", [])

    print(f"\n  Latin Aliases / aliases ({len(aliases)}):")
    for v in aliases:
        print(f"    - {v}")

    print(f"\n  Non-Latin Aliases / aliases_og ({len(aliases_og)}):")
    for v in aliases_og:
        print(f"    - {v}")

    print(f"\n  Total Aliases: {len(aliases) + len(aliases_og)}")
    return result


# ── Main run ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"\n>>> Running {len(all_cases)} case(s) from sample_hitl_inputs.json")

    all_results = []
    for case in all_cases:
        res = run_single_case(case)
        if res is not None:
            all_results.append({
                "_case_id":     case.get("_case_id"),
                "primary_name": case.get("primary_name"),
                "aliases":      res.get("aliases", []),
                "aliases_og":   res.get("aliases_og", []),
                "reasoning":    res.get("reasoning", ""),
                "error":        res.get("error"),
            })

    # Save output
    output_path = os.path.join(current_dir, "test_ec_flow_output.json")
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(all_results, fh, ensure_ascii=False, indent=2)

    print_separator("ALL CASES DONE")
    print(f"  Full output saved to: {output_path}")
