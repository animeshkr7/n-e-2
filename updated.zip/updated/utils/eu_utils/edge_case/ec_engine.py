"""
ec_engine.py
-------------
Orchestrates the full HITL-driven edge case flow.

Flow summary:
    HITL Input (complex_name, primary_name, context)
        ↓
    Load reference file (ec_reference_loader)
        ↓
    Similarity search: primary_name vs reference keys (ec_similarity_search)
        ↓
    Build prompt with top-X examples (ec_prompts)
        ↓
    LLM call → all possible name variations
        ↓
    Return structured output dict

This entire pipeline runs in a background thread (parallel to the main flow)
using the same ThreadPoolExecutor pattern as eu_name_engine_v2_utils.py.

Public API:
    run_edge_case_flow(...)          → blocking, returns result dict
    run_edge_case_flow_parallel(...) → non-blocking, returns Future
"""

import concurrent.futures
from service.logger.logger import get_logger

from utils.eu_utils.eu_common_utils import llm_call_and_parse_json_dict_response, llm_for_pydantic
from utils.eu_utils.edge_case.ec_reference_loader import load_reference_file
from utils.eu_utils.edge_case.ec_similarity_search import find_top_x_similar, DEFAULT_TOP_X
from utils.eu_utils.edge_case.ec_prompts import edge_case_generation_prompt

logger = get_logger("ec_engine")

# ── Configurable constants ─────────────────────────────────────────────────────
TOP_X: int = DEFAULT_TOP_X          # Number of reference examples to retrieve (default 5)
                                     # Change here to affect the whole flow globally.

EDGE_CASE_GATE_THRESHOLD: float = 0.90  # SequenceMatcher ratio >= this triggers edge case
                                         # 0.90 catches near-exact matches (OCR typos etc.)
                                         # Lower to 0.75 for a wider net.
EDGE_CASE_FUTURE_TIMEOUT: int = 120     # Seconds to wait for parallel edge case result
# ──────────────────────────────────────────────────────────────────────────────


def _merge_and_dedup(existing: list, new_items: list, primary_name: str) -> list:
    """Merge two alias lists, deduplicating case-insensitively and excluding primary_name."""
    primary_lower = primary_name.strip().lower()
    seen_lower = {n.strip().lower() for n in existing}
    result = list(existing)
    for name in new_items:
        name_s = name.strip()
        if name_s and name_s.lower() not in seen_lower and name_s.lower() != primary_lower:
            result.append(name_s)
            seen_lower.add(name_s.lower())
    return result


def apply_edge_case_gate(temp_output_list: list) -> list:
    """
    Post-processing gate applied after adjust_for_names() + permute_names().

    For each entity in temp_output_list:
        1. Computes top-1 similarity of entry["name"] vs reference file keys.
        2. If score >= EDGE_CASE_GATE_THRESHOLD, fires run_edge_case_flow_parallel().
        3. After all entities are submitted, collects futures (with EDGE_CASE_FUTURE_TIMEOUT).
        4. Merges and deduplicates edge case aliases into entry["aliases"] / entry["aliases_og"].

    The main flow output is ALWAYS returned unchanged on any failure — this gate is additive.

    Args:
        temp_output_list: list of entity dicts already processed by permute_names().

    Returns:
        The same list, with aliases/aliases_og potentially enriched for edge case entities.
    """
    if not temp_output_list:
        return temp_output_list

    try:
        reference_dict = load_reference_file()   # cached after first load
    except Exception as ref_err:
        logger.error(f"[ec_engine] apply_edge_case_gate: failed to load reference — skipping gate: {ref_err}")
        return temp_output_list

    futures_map: dict = {}   # { list_index: Future }

    # ── Phase 1: fire parallel jobs for matched entities ───────────────────────
    for i, entry in enumerate(temp_output_list):
        if not isinstance(entry, dict):
            continue
        primary_name = entry.get("name") or entry.get("primary_name", "")
        if not primary_name:
            continue

        top1 = find_top_x_similar(primary_name, reference_dict, top_x=1)
        if top1 and top1[0]["score"] >= EDGE_CASE_GATE_THRESHOLD:
            logger.info(
                f"[ec_engine] Gate triggered for '{primary_name}' "
                f"(score={top1[0]['score']:.4f} vs '{top1[0]['key']}')"
            )
            complex_name = entry.get("name_info", primary_name)
            if isinstance(complex_name, list):
                complex_name = " ".join(complex_name)
            future = run_edge_case_flow_parallel(
                complex_name=complex_name,
                primary_name=primary_name,
                context=entry,          # full entry dict — contains completeInformation etc.
            )
            futures_map[i] = future
        else:
            score_str = f"{top1[0]['score']:.4f}" if top1 else "n/a"
            logger.info(f"[ec_engine] Gate not triggered for '{primary_name}' (top score={score_str})")

    if not futures_map:
        return temp_output_list

    # ── Phase 2: collect and merge ─────────────────────────────────────────────
    for i, future in futures_map.items():
        try:
            ec_result = future.result(timeout=EDGE_CASE_FUTURE_TIMEOUT)
            if ec_result.get("error"):
                logger.error(f"[ec_engine] Gate future error for index {i}: {ec_result['error']}")
                continue

            entry        = temp_output_list[i]
            primary_name = entry.get("name") or entry.get("primary_name", "")

            entry["aliases"]    = _merge_and_dedup(
                entry.get("aliases", []), ec_result.get("aliases", []), primary_name
            )
            entry["aliases_og"] = _merge_and_dedup(
                entry.get("aliases_og", []), ec_result.get("aliases_og", []), primary_name
            )
            logger.info(
                f"[ec_engine] Gate merged for '{primary_name}': "
                f"{len(entry['aliases'])} Latin aliases, "
                f"{len(entry['aliases_og'])} non-Latin aliases after merge."
            )
        except concurrent.futures.TimeoutError:
            logger.error(f"[ec_engine] Gate future timed out after {EDGE_CASE_FUTURE_TIMEOUT}s for index {i}")
        except Exception as fut_err:
            logger.error(f"[ec_engine] Gate future collection error for index {i}: {fut_err}")

    return temp_output_list


def run_edge_case_flow(
    complex_name: str,
    primary_name: str,
    context: dict | str,
    reference_path: str = None,
    top_x: int = TOP_X,
) -> dict:
    """
    Blocking execution of the full edge case flow.

    Args:
        complex_name:    The raw, complex sanctioned entity name string.
                         This is the PRIMARY input — the main thing to process.
        primary_name:    The clean primary name of the entity.
        context:         All entity context (dict or stringified JSON from the PR).
        reference_path:  Optional custom path to the reference JSON file.
                         If None, uses the default constants/edge_case_reference.json.
        top_x:           Number of top similar reference examples to include in prompt.
                         Configurable at the top of this file via TOP_X.

    Returns:
        dict with keys:
            "complex_name"       : str        — echoed input
            "primary_name"       : str        — echoed input
            "aliases"            : list[str]  — Latin-script name variations  (= main flow aliases)
            "aliases_og"         : list[str]  — Non-Latin name variations     (= main flow aliases_og)
            "reasoning"          : str        — LLM's interpretation note
            "similar_cases_used" : list       — reference cases passed to LLM
            "error"              : str | None — any error that occurred
    """
    result = {
        "complex_name":        complex_name,
        "primary_name":        primary_name,
        "aliases":             [],   # Latin-script variations    — matches main flow
        "aliases_og":          [],   # Non-Latin-script variations — matches main flow
        "reasoning":           "",
        "similar_cases_used":  [],
        "error":               None,
    }

    try:
        logger.info(
            f"[ec_engine] Starting edge case flow | "
            f"primary_name='{primary_name}' | complex_name='{complex_name[:60]}...'"
        )

        # ── Step 1: Load reference file ────────────────────────────────────────
        load_kwargs = {"path": reference_path} if reference_path else {}
        reference_dict = load_reference_file(**load_kwargs)
        logger.info(f"[ec_engine] Reference file loaded — {len(reference_dict)} keys.")

        # ── Step 2: Similarity search ──────────────────────────────────────────
        similar_cases = find_top_x_similar(primary_name, reference_dict, top_x=top_x)
        result["similar_cases_used"] = similar_cases
        logger.info(f"[ec_engine] Similarity search done — {len(similar_cases)} cases selected.")

        # ── Step 3: Build prompt ───────────────────────────────────────────────
        messages = edge_case_generation_prompt(
            complex_name=complex_name,
            primary_name=primary_name,
            context=context,
            similar_edge_cases=similar_cases,
        )

        # ── Step 4: LLM call ───────────────────────────────────────────────────
        logger.info("[ec_engine] Calling LLM for edge case name generation...")
        llm_output = llm_call_and_parse_json_dict_response(messages, model=llm_for_pydantic)
        aliases    = llm_output.get("aliases", [])
        aliases_og = llm_output.get("aliases_og", [])
        logger.info(
            f"[ec_engine] LLM responded: {len(aliases)} Latin aliases, "
            f"{len(aliases_og)} non-Latin aliases."
        )

        # ── Step 5: Populate result (same keys as main flow permute_names output) ──
        result["aliases"]    = aliases
        result["aliases_og"] = aliases_og
        result["reasoning"]  = llm_output.get("reasoning", "")

    except Exception as exc:
        logger.error(f"[ec_engine] Error in run_edge_case_flow: {exc}")
        result["error"] = str(exc)

    return result


def run_edge_case_flow_parallel(
    complex_name: str,
    primary_name: str,
    context: dict | str,
    reference_path: str = None,
    top_x: int = TOP_X,
) -> concurrent.futures.Future:
    """
    Non-blocking (parallel) execution of the edge case flow.

    Fires the pipeline in a background thread and immediately returns a Future.
    The main extraction pipeline continues uninterrupted.

    Usage:
        future = run_edge_case_flow_parallel(complex_name, primary_name, context)
        # ... main flow continues ...
        result = future.result(timeout=120)   # optionally wait for result later

    Args:
        Same as run_edge_case_flow.

    Returns:
        concurrent.futures.Future — call .result() to get the output dict.
    """
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    future = executor.submit(
        run_edge_case_flow,
        complex_name,
        primary_name,
        context,
        reference_path,
        top_x,
    )
    logger.info(
        f"[ec_engine] Edge case flow submitted to background thread for '{primary_name}'."
    )
    return future
