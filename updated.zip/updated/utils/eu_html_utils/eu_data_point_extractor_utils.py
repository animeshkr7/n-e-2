from service.logger.logger import get_logger
from service.exception.exception import ExtractorException

from utils.eu_html_utils.eu_url_parser_utils import get_html_text_oj_tables_seperate, copy_html_soup, remove_the_header_row_from_a_bs_row
from utils.eu_html_utils.eu_html_common_utils import check_duplicate_names

from utils.eu_html_utils.eu_html_prompts import data_point_extractor_system_prompt_1, data_points_extractor, extractor_system_prompt_3_7
from utils.eu_utils.eu_name_aliases_utils import adjust_for_names, permute_names
from utils.eu_utils.eu_name_engine_v2_utils import run_name_engine_v2_pipeline
from utils.eu_utils.edge_case.ec_engine import apply_edge_case_gate
from utils.eu_utils.eu_common_utils import retry_llm_calls_with_constant_delay, get_messages, get_stop_reason_from_llm_response, get_text_from_llm_response,LLMFault

import json
import asyncio
logger = get_logger("eu_data_point_extractor_utils")


def get_name_adjusted_records(temp_output_list: list) -> list:
    """Shared helper: adjust_for_names → permute_names → name_engine_v2 → edge_case_gate."""
    if not temp_output_list:
        return []
    temp_output_list = adjust_for_names(temp_output_list)
    temp_output_list = permute_names(temp_output_list)
    try:
        raw_names = [
            item.get("name") or item.get("primary_name", "")
            for item in temp_output_list if isinstance(item, dict)
        ]
        raw_names = [n for n in raw_names if n]
        if raw_names:
            run_name_engine_v2_pipeline(raw_names, [])
    except Exception as v2_err:
        logger.error(f"Error triggering Name Engine V2: {v2_err}")
    temp_output_list = apply_edge_case_gate(temp_output_list)  # ← edge case gate (parallel, additive)
    return temp_output_list

async def perform_data_point_extraction(fullcontenthtml,i):
    try:
        contents, _, image_links= get_html_text_oj_tables_seperate(fullcontenthtml) #html is passed to tables
        final_output_list = await parallelized_processing(contents)
        return final_output_list, i, image_links
    except Exception as E:
        raise ExtractorException(f"Error in perform_data_point_extraction: {E}")

async def parallelized_processing(contents):
    individuals_data_full = []
    
    # Use asyncio.to_thread to run blocking tasks in parallel
    tasks = [asyncio.to_thread(process_content, content) for content in contents]
    
    # Gather results concurrently
    results = await asyncio.gather(*tasks)
    
    # Collect all individual results
    for individuals_data in results:
        individuals_data_full.extend(individuals_data)

    final_output_list = individuals_data_full
    return final_output_list

def process_content(content_as_dictionary):
    data_present_in_content = []
    num_of_llm_calls_made_in_content = 0
    try:
        # This is the synchronous code that handles each individual content
        if not isinstance(content_as_dictionary, dict):
            raise ExtractorException("content is not a dictionary")
        is_row = False
        for key, value in content_as_dictionary.items():
            if key == "row":
                is_row = True
            input_content_for_LLM_call = value
        output_message = get_first_call_output(input_content_for_LLM_call)
        data_present_in_content, num_of_llm_calls_made_in_content = check_for_overflowing_context_limit(
                                                                            data_present_in_content, 
                                                                            input_content_for_LLM_call, 
                                                                            num_of_llm_calls_made_in_content, 
                                                                            output_message
                                                                            )
        data_present_in_content = modify_additional_info_incase_of_rows(is_row,data_present_in_content, input_content_for_LLM_call)
    except Exception as E:
        logger.error(f"Error in process_content for content: {content_as_dictionary} as error: {E}")
    return data_present_in_content

def get_first_call_output(content):
    try:
        response_extractor_first_call = retry_llm_calls_with_constant_delay(get_messages(
                                                                                f"content: {content}",
                                                                                f"""{data_point_extractor_system_prompt_1}\n\nData Points: {data_points_extractor}"""
                                                                                    )
                                                                            )
        return response_extractor_first_call 
    except Exception as E:
        raise ExtractorException(f"error in get_first_call_output: {E}")

def modify_additional_info_incase_of_rows(is_row,data_present_in_content, input_content_for_LLM_call):
    try:
        if not is_row:
            return data_present_in_content
        for entry in data_present_in_content:
            try:
                if not isinstance(entry, dict):  # Ensure it's a dictionary before updating
                    logger.error(f"{entry} is not a dictionary")
                else:
                    content_as_soup = copy_html_soup(input_content_for_LLM_call)
                    header_removed_row_as_soup = remove_the_header_row_from_a_bs_row(content_as_soup)
                    replaced_row = header_removed_row_as_soup.get_text(strip=True, separator=" ")
                    entry["completeInformation"] = replaced_row
            except Exception as E:
                logger.error(f"Error in modify_additional_info_incase_of_rows for entry: {entry}, error: {E}")
    except Exception as E:
        logger.error(f"Error in modify_additional_info_incase_of_rows error: {E}")
    return data_present_in_content

def get_content_extractor_first_call(webpage_content, data_points_extractor):
    return (
        f"content: {webpage_content}\n\n"
        f"Data Points: {data_points_extractor}"
        )

def check_for_overflowing_context_limit(individuals_data, content, i, output_message):
    intermediate_op_list_flag = "in_progress"
    output_list = []
    try:
        while intermediate_op_list_flag == "in_progress":
            last_entity,intermediate_op_list, intermediate_op_list_flag = curate_intermediate_output_list( 
                                                                                                    output_message, 
                                                                                                    output_list
                                                                                                    )
            if intermediate_op_list_flag == "completed" and intermediate_op_list is not None:
                logger.info("Extraction is completed!!")
                output_list = intermediate_op_list
            elif intermediate_op_list_flag == "in_progress" and intermediate_op_list is not None:
                logger.info("Making an LLM call with restructured prompt!!")
                i += 1
                response_extractor_subsequent_calls = get_subsequent_calls_output(content, last_entity)
                output_message = response_extractor_subsequent_calls
                output_list = intermediate_op_list

            if check_duplicate_names(output_list):
                raise LLMFault("There are duplicates in this LLM call list ask the analyst to verify crucial","duplication")
            # - if duplicate_extraction observed - raise an exception anda notif for a manual run
            # - set a hard limit on number of calls allowed, based on the tokens (check the backtested o/p tokens)
        
        logger.info(f"Number of LLM calls made uptill this annex/content: {i}")
        individuals_data.extend(output_list)
        if check_duplicate_names(individuals_data):
            logger.info("There are duplicates in list for all annex contents ask the analyst to verify")
        return individuals_data, i
    except Exception as E:
        raise ExtractorException(f"Error in check for overflowing context limit: {E}")

def curate_intermediate_output_list(chat_completions, output_list):
    """
        inputs: LLM output, output list
        output: lastentity, Updated output list, completion_flag
    """
    stop_reason = get_stop_reason_from_llm_response(chat_completions)
    text_content = get_text_from_llm_response(chat_completions)

    logger.info(f"Output text string is: \n{text_content}")
    logger.info(f"Output stop_reason is: {stop_reason}")

    if stop_reason == 'length':
        logger.info("Notify analyst to verify this output as an additional layer of safety.")
        last_entity, updated_intermediate_output_list = update_intermediate_output_list_with_new_entries(output_list, text_content)
        if last_entity is None: #The output stoped due to context limit but there is no last entity
            logger.info("The output stoped due to context limit but output list could not be updated")
            return None, updated_intermediate_output_list, "completed"
        return last_entity,updated_intermediate_output_list, "in_progress"
    
    elif stop_reason == 'stop':
        logger.info("LLM terminated gracefully")
        try:
            temp_output_list = json.loads(text_content)
            temp_output_list = temp_output_list.get("result")
            if temp_output_list is None:
                raise ValueError("The 'result' key is missing in the JSON content.")
            temp_output_list = get_name_adjusted_records(temp_output_list)
            output_list.extend(temp_output_list)
            return None, output_list, "completed"
        except Exception as e:
            logger.error(f"LLM response has stop_reason == 'stop' in curate_intermediate_output_list but still json.loads failed. Error: {e}")
            return None, output_list, "completed"
    else:
        logger.info(f"LLM has stopped due to unknown reason: {stop_reason}")
        return None, output_list, "completed"

def update_intermediate_output_list_with_new_entries(output_list, json_text_content):
    try:
        json_text_content = get_json_parsable_string_from_llm_output(json_text_content)
        temp_output_list = json.loads(json_text_content)
        temp_output_list = temp_output_list.get("result")
        if temp_output_list is None:
            raise ValueError("The 'result' key is missing in the JSON content.")
        temp_output_list = get_name_adjusted_records(temp_output_list)
        last_entity = temp_output_list[-1]
        last_entity = last_entity.get("name")
        logger.info(f"Last entry is:{last_entity}")
        logger.info(f"Total entries in output_list pre-update: {len(output_list)}")
        logger.info(f"Total entries in this update: {len(temp_output_list)}")

        output_list.extend(temp_output_list)
        logger.info(f"Total entries in output_list post-update: {len(output_list)}")

        return last_entity, output_list                
    except Exception as e:
        logger.error(f"Error occurred while update_intermediate_output_list_with_new_entries: {e}")
        return None, output_list  # Return None to indicate an error
    
def get_json_parsable_string_from_llm_output(data: str):
    """ input: string, 
        output: json parsable string
    """
    try:
        lines = data.strip().split('\n')
        found_brace = False
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].strip() == '},' and 'id_remarks' not in lines[i - 1] and "wholeNameVariations" not in lines[i-1]:
                found_brace = True
                break

        if found_brace:
            output_lines = lines[:i+1]
            output_string = '\n'.join(output_lines)
            output_string_ready_for_json_loads = output_string[:-1] + "]}"
            return output_string_ready_for_json_loads
        else:
            raise ExtractorException(f"No ',' found in the data. {data}")
    except Exception as E:
        raise ExtractorException(f"Error in getting json parsable string from llm output: {E}input is {data}")

def get_subsequent_calls_output(content, last_entity):
    try:    
        response_extractor_subsequent_calls = retry_llm_calls_with_constant_delay(get_messages(
                                                                                            get_content_extractor_subsequent_calls(
                                                                                                        content,
                                                                                                        last_entity
                                                                                                ),
                                                                                            f"""{extractor_system_prompt_3_7}\n\ndata_points_extractor: {data_points_extractor}"""
                                                                                        )
                                                                                        )
        return response_extractor_subsequent_calls
    except Exception as E:
        raise ExtractorException(f"error in get_subsequent_calls_output: {E}, with last_entity:{last_entity}")

def get_content_extractor_subsequent_calls(webpage_content, previously_extracted_body):
    return (
        f"content: {webpage_content}\n\n"
        f"previously_extracted_body: {previously_extracted_body}"
    )