import json

def edge_case_part_split(name_info):
    prompt = """
You are an expert at analyzing and organizing complex, highly irregular names into structured arrays.
You will be given a complex sanctioned entity name as input. This name may contain extreme formatting anomalies, mixed Arabic/Latin scripts, heavy nested brackets, and confusing punctuation.

Your task is to cleanly extract the parts of the name into `first`, `middle`, `last`, and `allFullNameVariants` arrays.

**CRITICAL GUIDELINES FOR EDGE CASES:**
1. **Trailing Arabic Names:** If you encounter trailing non-Latin characters (like Arabic) in brackets, e.g., `(حمشو عماد)`, treat it strictly as a completely separate standalone name and put it in `allFullNameVariants`. DO NOT merge it into the `last` name array or any other array.
2. **Aliases in Brackets:** If you see `(a.k.a. Name1; Name2)`, those are usually aliases of the LAST name unless specified otherwise. Do not put them in the `first` name array.
3. **Missing Parts:** It is very common for these names to have NO middle name. If there is no explicit middle name, leave the `partValue` for middle empty and its `aliases` empty. Do not guess.
4. **Scattered Full Name Aliases:** If you see multiple distinct full names separated by `a.k.a.`, slashes `/`, or commas `,` outside of brackets (e.g., `Name1 a.k.a. Name2, Name3`), extract the very first name into the `first/middle/last` parts. Put all subsequent full names STRICTLY into the `allFullNameVariants` array. Do NOT break them into pieces or put them in the `first` or `last` name arrays.
5. **Nested Optional Names:** If a full name contains a nested optional name in brackets (e.g., `Name1 (Name2) Name3`), you MUST expand it into two separate valid combinations in `allFullNameVariants` (e.g., `Name1 Name3` and `Name2 Name3`). Do not output the literal brackets.

**EXAMPLES (Use these as a strict guide):**

Example 1 (Mixed Script & Trailing Brackets):
Input: `['Usham LAMSHO(a.k.a. Osham Lmisho; Lamchu; Lemisho, حميشو)(حمشو عماد)']`
Output:
{
  "titles": [],
  "primaryFullName": "Usham LAMSHO",
  "nameParts": [
    {"partValue": "Usham", "partLabel": "first", "aliases": ["Osham"]},
    {"partValue": "", "partLabel": "middle", "aliases": []},
    {"partValue": "LAMSHO", "partLabel": "last", "aliases": ["Lmisho", "Lamchu", "Lemisho", "حميشو"]}
  ],
  "allFullNameVariants": ["حمشو عماد"],
  "nicknames": []
}

Example 2 (Complex Latin Aliases):
Input: `['John Doe (Good quality alias (a) Jonathan Dow, (b) Johnathon Daugh; Low quality alias (a) Jon Do)']`
Output:
{
  "titles": [],
  "primaryFullName": "John Doe",
  "nameParts": [
    {"partValue": "John", "partLabel": "first", "aliases": ["Jonathan", "Johnathon", "Jon"]},
    {"partValue": "", "partLabel": "middle", "aliases": []},
    {"partValue": "Doe", "partLabel": "last", "aliases": ["Dow", "Daugh", "Do"]}
  ],
  "allFullNameVariants": [],
  "nicknames": []
}

Example 3 (Simple Mix):
Input: `['Jhon Bilal(سمير حسن)']`
Output:
{
  "titles": [],
  "primaryFullName": "Jhon Bilal",
  "nameParts": [
    {"partValue": "Jhon", "partLabel": "first", "aliases": []},
    {"partValue": "", "partLabel": "middle", "aliases": []},
    {"partValue": "Bilal", "partLabel": "last", "aliases": []}
  ],
  "allFullNameVariants": ["سمير حسن"],
  "nicknames": []
}

Example 4 (Scattered Full Name Aliases & Nested Brackets):
Input: `['Vladimir Gheorghe PLAHOTNIUC a.k.a. Vladimir ULINICI a.k.a. Mihail TAUȘANOV / Mikhail TAUSHANOV (Владимир (Влад) Георгиевич ПЛАХОТНЮК)']`
Output:
{
  "titles": [],
  "primaryFullName": "Vladimir Gheorghe PLAHOTNIUC",
  "nameParts": [
    {"partValue": "Vladimir", "partLabel": "first", "aliases": []},
    {"partValue": "Gheorghe", "partLabel": "middle", "aliases": []},
    {"partValue": "PLAHOTNIUC", "partLabel": "last", "aliases": []}
  ],
  "allFullNameVariants": ["Vladimir ULINICI", "Mihail TAUȘANOV", "Mikhail TAUSHANOV", "Владимир Георгиевич ПЛАХОТНЮК", "Влад Георгиевич ПЛАХОТНЮК"],
  "nicknames": []
}

Return exactly the JSON format shown above. Do not wrap in markdown blocks, just return valid JSON.

Now, process this input:
{name_info}
"""
    # Replace {name_info} manually to avoid f-string curly brace issues with JSON
    prompt = prompt.replace("{name_info}", str(name_info))
    
    messages=[
        {
            "role": "user",
            "content": prompt
        }
    ]
    return messages
