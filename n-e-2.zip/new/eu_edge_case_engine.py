import re
from service.logger.logger import get_logger
from utils.eu_utils.eu_common_utils import llm_call_and_parse_json_dict_response
from utils.eu_utils.eu_prompts_v2 import edge_case_part_split

logger = get_logger("eu_edge_case_engine")

def detect_edge_case(name_info):
    """
    Fast heuristic to detect if the incoming name_info matches the complex
    edge cases found in data.xlsx.
    """
    if not name_info:
        return False
        
    name_info_str = str(name_info)
    
    # 1. Mixed Scripts: Specifically Arabic or Cyrillic blocks mixed in
    has_arabic_or_cyrillic = bool(re.search(r'[\u0600-\u06FF\u0400-\u04FF]', name_info_str))
    
    # 2. Complex Brackets: ")(", or nested brackets like "(...(...)...)"
    has_complex_brackets = ')(' in name_info_str.replace(' ', '') or bool(re.search(r'\([^)]*\([^)]*\)[^)]*\)', name_info_str))
    
    # 3. Dense Aliases: Multiple delimiters or weirdly spaced a.k.a tags
    normalized_str = name_info_str.replace(' ', '').lower()
    has_dense_aliases = bool(re.search(r'\([^)]*;[^)]*;[^)]*\)', name_info_str))
    has_scattered_akas = normalized_str.count("a.k.a.") >= 2 or normalized_str.count("aka") >= 2
    
    # Catch comma-separated lists that follow an alias tag
    has_comma_list = "a.k.a." in normalized_str and name_info_str.count(",") >= 2
    
    is_edge = has_arabic_or_cyrillic or has_complex_brackets or has_dense_aliases or has_scattered_akas or has_comma_list
    
    if is_edge:
        logger.info(f"Edge case detected for input: {name_info_str}")
        
    return is_edge

def process_edge_case(entry):
    """
    Bypasses the standard 3-call pipeline and uses a single, highly specialized
    Few-Shot LLM prompt to perfectly extract the name parts for edge cases.
    """
    try:
        name_related_info = entry.get("name_info")
        
        # 1. Call specialized prompt
        message = edge_case_part_split(name_related_info)
        response_dict = llm_call_and_parse_json_dict_response(message)
        
        # 2. Map the prompt's output format to the internal name_alias_info format
        first_names, middle_names, last_names, whole_names = [], [], [], []
        titles = response_dict.get("titles", [])
        primary_full_name = response_dict.get("primaryFullName", "")
        
        if primary_full_name:
            whole_names.append(primary_full_name)
            
        for part in response_dict.get("nameParts", []):
            label = part.get("partLabel")
            val = part.get("partValue")
            aliases = part.get("aliases", [])
            
            target_list = None
            if label == "first":
                target_list = first_names
            elif label == "middle":
                target_list = middle_names
            elif label == "last":
                target_list = last_names
                
            if target_list is not None:
                if val:
                    target_list.append(val)
                if aliases:
                    target_list.extend(aliases)
                    
        # Add full name variants and nicknames
        whole_names.extend(response_dict.get("allFullNameVariants", []))
        whole_names.extend(response_dict.get("nicknames", []))
        
        # 3. Attach to entry in the EXACT format expected by permute_names
        entry["name_alias_info"] = {
            "titles": titles,
            "primaryName": primary_full_name,
            "wholeNameVariations": whole_names,
            "firstNameVariations": first_names,
            "middleNameVariations": middle_names,
            "lastNameVariations": last_names
        }
        
    except Exception as e:
        logger.error(f"Failed to process edge case: {e}")
        # If it fails, attach a safe empty dict so it doesn't crash the pipeline
        entry["name_alias_info"] = {
            "titles": [],
            "primaryName": "",
            "wholeNameVariations": [],
            "firstNameVariations": [],
            "middleNameVariations": [],
            "lastNameVariations": []
        }
        
    return entry
