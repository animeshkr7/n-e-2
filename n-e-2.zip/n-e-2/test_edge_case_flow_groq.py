import os
import json
import sys

# Add root directory to path so imports work correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure Groq API key is available
if not os.environ.get("GROQ_API_KEY"):
    print("ERROR: GROQ_API_KEY environment variable not set.")
    sys.exit(1)

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai library not found.")
    sys.exit(1)

# -----------------------------------------------------------------------------
# MONKEY-PATCHING OPENAI CLIENT TO USE GROQ
# -----------------------------------------------------------------------------
groq_client = OpenAI(
    api_key=os.environ.get("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1"
)

import utils.eu_utils.eu_common_utils as eu_common_utils
eu_common_utils.client = groq_client

original_llm_call = eu_common_utils.llm_call_open_ai

def force_groq_model_call(message, model=None):
    # Force Groq's 8B model to easily handle the generous free tier
    return original_llm_call(message, model="llama-3.1-8b-instant")

eu_common_utils.llm_call_open_ai = force_groq_model_call

# -----------------------------------------------------------------------------
# RUNNING THE TEST FOR THE EDGE CASE ENGINE
# -----------------------------------------------------------------------------

from utils.eu_utils.eu_name_aliases_utils import adjust_for_names, permute_names
import logging

logging.basicConfig(level=logging.INFO)

def run_test():
    # User-provided Test Case (Comma-separated aliases after a.k.a.)
    test_entry = {
        "name": "Naji Ibrahim SHARIFI-ZINDASHTI",
        "entityType": "individual",
        "name_info": "['Naji Ibrahim SHARIFI-ZINDASHTI a. k.a. KENANI, Emirhan SERIFI ZINDASTI, Naci SERIFI-ZINDASTI, Naci SHARIF']"
    }
    
    print("="*60)
    print(f"TESTING *INTEGRATED* EDGE CASE FLOW WITH GROQ")
    print(f"Input Name Info: {test_entry['name_info']}")
    print("="*60)
    
    # 1. We just call adjust_for_names! The routing happens automatically inside it.
    print("\n1. Running adjust_for_names (Automatic Routing)...")
    adjusted_list = adjust_for_names([test_entry])
    
    print("\nExtracted Name Dictionary (Output of the engine):")
    if adjusted_list and 'name_alias_info' in adjusted_list[0]:
        print(json.dumps(adjusted_list[0]['name_alias_info'], indent=2, ensure_ascii=False))
    
    # 2. Existing Permutation & Combination
    print("\n2. Running existing permute_names (Permutation & Combination)...")
    final_output = permute_names(adjusted_list)
    
    print("\n="*60)
    print("FINAL OUTPUT (Permutations):")
    print("="*60)
    
    if final_output:
        print("Aliases (Latin):")
        print(json.dumps(final_output[0].get('aliases', []), indent=2, ensure_ascii=False))
        print("\nAliases_OG (Non-Latin):")
        print(json.dumps(final_output[0].get('aliases_og', []), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    run_test()
