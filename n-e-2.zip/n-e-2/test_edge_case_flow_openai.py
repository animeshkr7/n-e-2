import os
import json
import sys

# Add root directory to path so imports work correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Verify OpenAI key is available (the pipeline reads it from Config.OPENAI_API_KEY)
from config.config import Config
if not Config.OPENAI_API_KEY:
    print("ERROR: OPENAI_API_KEY is not set in your config/environment.")
    print("Please set it: $env:OPENAI_API_KEY='your_key'")
    sys.exit(1)

# -----------------------------------------------------------------------------
# NO MONKEY-PATCHING NEEDED — the pipeline natively uses OpenAI (gpt-4o)
# -----------------------------------------------------------------------------

from utils.eu_utils.eu_name_aliases_utils import adjust_for_names, permute_names
import logging

logging.basicConfig(level=logging.INFO)

def run_test():
    test_entry = {
        "name": "Naji Ibrahim SHARIFI-ZINDASHTI",
        "entityType": "individual",
        "name_info": "['Naji Ibrahim SHARIFI-ZINDASHTI a. k.a. KENANI, Emirhan SERIFI ZINDASTI, Naci SERIFI-ZINDASTI, Naci SHARIF']"
    }
    
    print("="*60)
    print(f"TESTING *INTEGRATED* EDGE CASE FLOW WITH OPENAI (gpt-4o)")
    print(f"Input Name Info: {test_entry['name_info']}")
    print("="*60)
    
    # 1. We just call adjust_for_names! The routing happens automatically inside it.
    print("\n1. Running adjust_for_names (Automatic Routing)...")
    adjusted_list = adjust_for_names([test_entry])
    
    print("\nExtracted Name Dictionary (Output of the engine):")
    if adjusted_list and 'name_alias_info' in adjusted_list[0]:
        print(json.dumps(adjusted_list[0]['name_alias_info'], indent=2, ensure_ascii=False))
    
    # 2. Existing Permutation & Combination
    print("\n2. Running existing permute_names (Permutation & Combination)...")
    final_output = permute_names(adjusted_list)
    
    print("\n" + "="*60)
    print("FINAL OUTPUT (Permutations):")
    print("="*60)
    
    if final_output:
        print("Aliases (Latin):")
        print(json.dumps(final_output[0].get('aliases', []), indent=2, ensure_ascii=False))
        print("\nAliases_OG (Non-Latin):")
        print(json.dumps(final_output[0].get('aliases_og', []), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    run_test()
