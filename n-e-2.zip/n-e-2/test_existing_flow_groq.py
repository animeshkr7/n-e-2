import os
import json
import sys

# Add root directory to path so imports work correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure Groq API key is available
if not os.environ.get("GROQ_API_KEY"):
    print("ERROR: GROQ_API_KEY environment variable not set.")
    print("Please get a free key from console.groq.com")
    print("Then set it: $env:GROQ_API_KEY='your_key'")
    sys.exit(1)

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai library not found.")
    print("Please install it: pip install openai")
    sys.exit(1)

# -----------------------------------------------------------------------------
# MONKEY-PATCHING OPENAI CLIENT TO USE GROQ
# -----------------------------------------------------------------------------
# Groq provides an OpenAI-compatible API. We just point the OpenAI client to Groq!

groq_client = OpenAI(
    api_key=os.environ.get("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1"
)

# Import the existing module
import utils.eu_utils.eu_common_utils as eu_common_utils

# Replace the OpenAI client with our Groq client
eu_common_utils.client = groq_client

# Python evaluates default arguments at import time, so overriding variables won't work.
# We must monkey-patch the actual function to force the Groq model.
original_llm_call = eu_common_utils.llm_call_open_ai

def force_groq_model_call(message, model=None):
    # Ignore whatever model the codebase passes and force Groq's 8B model (which has huge free tier limits)
    return original_llm_call(message, model="llama-3.1-8b-instant")

eu_common_utils.llm_call_open_ai = force_groq_model_call

# -----------------------------------------------------------------------------
# RUNNING THE TEST
# -----------------------------------------------------------------------------

from utils.eu_utils.eu_name_aliases_utils import adjust_for_names, permute_names
import logging

# Reduce noise from existing loggers
logging.basicConfig(level=logging.INFO)

def run_test():
    # New complex test case
    test_entry = {
        "name": "Vladimir Gheorghe PLAHOTNIUC",
        "entityType": "individual",
        "name_info": "['Vladimir Gheorghe PLAHOTNIUC a.k.a. Vladimir ULINICI a.k.a. Vladimir PLAKHOTNYUK a.k.a. Vladislav Vladimir NOVAK a.k.a. Mihail TAUȘANOV / Mikhail TAUSHANOV (Владимир (Влад) Георгиевич ПЛАХОТНЮК)']"
    }
    
    print("="*60)
    print(f"TESTING EXISTING FLOW WITH GROQ (Llama 3 70B)")
    print(f"Input Name Info: {test_entry['name_info']}")
    print("="*60)
    
    print("\n1. Running adjust_for_names (Extracting parts via LLM)...")
    adjusted_list = adjust_for_names([test_entry])
    
    # Peek at the extracted dictionary before P&C
    print("\nExtracted Name Dictionary (Output of generalized prompt):")
    if adjusted_list and 'name_alias_info' in adjusted_list[0]:
        print(json.dumps(adjusted_list[0]['name_alias_info'], indent=2, ensure_ascii=False))
    
    print("\n2. Running permute_names (Permutation & Combination)...")
    final_output = permute_names(adjusted_list)
    
    print("\n="*60)
    print("FINAL OUTPUT (Permutations):")
    print("="*60)
    
    if final_output:
        print("Aliases (Latin):")
        print(json.dumps(final_output[0].get('aliases', []), indent=2, ensure_ascii=False))
        print("\nAliases_OG (Non-Latin):")
        print(json.dumps(final_output[0].get('aliases_og', []), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    run_test()
