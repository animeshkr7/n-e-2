import os
import json
import sys

# Add root directory to path so imports work correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure Gemini API key is available
if not os.environ.get("GEMINI_API_KEY"):
    print("ERROR: GEMINI_API_KEY environment variable not set.")
    print("Please set it before running: $env:GEMINI_API_KEY='your_key'")
    sys.exit(1)

# Import and configure Gemini
try:
    import google.generativeai as genai
except ImportError:
    print("ERROR: google-generativeai library not found.")
    print("Please install it: pip install google-generativeai")
    sys.exit(1)

genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
# Using Gemini 1.5 Flash as it is fast, free, and excellent for JSON generation
gemini_model = genai.GenerativeModel('gemini-2.5-flash')

# -----------------------------------------------------------------------------
# MONKEY-PATCHING OPENAI TO GEMINI
# -----------------------------------------------------------------------------

# We create mock classes so the rest of the codebase thinks it received an OpenAI response
class DummyMessage:
    def __init__(self, content):
        self.content = content

class DummyChoice:
    def __init__(self, content):
        self.message = DummyMessage(content)
        self.finish_reason = "stop"

class DummyResponse:
    def __init__(self, content):
        self.choices = [DummyChoice(content)]

def mock_llm_call_open_ai(message, model=None):
    """
    This replaces the OpenAI call in the codebase with a Gemini call.
    It takes the OpenAI messages list, converts it to a single prompt, 
    calls Gemini, and returns a mock OpenAI response object.
    """
    prompt = ""
    for m in message:
        prompt += f"{m['role'].upper()} INSTRUCTIONS:\n{m['content']}\n\n"
    
    # Force JSON format via prompt in case older SDK doesn't support json mode
    prompt += "\nMake sure your final output is ONLY valid JSON, nothing else."
    
    import time
    print(f"\n[Rate Limit Pause] Waiting 12 seconds for Gemini free tier limits...")
    time.sleep(12)
    
    try:
        response = gemini_model.generate_content(prompt)
        # Clean up Markdown formatting if Gemini added it
        raw_text = response.text.strip()
        if raw_text.startswith("```json"):
            raw_text = raw_text[7:]
        if raw_text.endswith("```"):
            raw_text = raw_text[:-3]
            
        return DummyResponse(raw_text.strip())
    except Exception as e:
        print(f"Gemini API Error: {e}")
        return None

# Now we apply the patch before running the main logic
import utils.eu_utils.eu_common_utils as eu_common_utils
eu_common_utils.llm_call_open_ai = mock_llm_call_open_ai

# -----------------------------------------------------------------------------
# RUNNING THE TEST
# -----------------------------------------------------------------------------

from utils.eu_utils.eu_name_aliases_utils import adjust_for_names, permute_names
import logging

# Reduce noise from existing loggers if needed
logging.basicConfig(level=logging.INFO)

def run_test():
    # Example Edge Case Input
    test_entry = {
        "name": "Usham LAMSHO",
        "entityType": "individual",
        "name_info": "['Usham LAMSHO(a.k.a. Osham Lmisho; Lamchu; Lemisho, حميشو)(حمشو عماد)']"
    }
    
    print("="*60)
    print(f"TESTING EXISTING FLOW WITH GEMINI")
    print(f"Input Name Info: {test_entry['name_info']}")
    print("="*60)
    
    print("\n1. Running adjust_for_names (Extracting parts via LLM)...")
    adjusted_list = adjust_for_names([test_entry])
    
    # Let's peek at the extracted dictionary before P&C
    print("\nExtracted Name Dictionary (Output of generalized prompt):")
    if adjusted_list and 'name_alias_info' in adjusted_list[0]:
        print(json.dumps(adjusted_list[0]['name_alias_info'], indent=2, ensure_ascii=False))
    
    print("\n2. Running permute_names (Permutation & Combination)...")
    final_output = permute_names(adjusted_list)
    
    print("\n="*60)
    print("FINAL OUTPUT (Permutations):")
    print("="*60)
    
    if final_output:
        print("Aliases (Latin):")
        print(json.dumps(final_output[0].get('aliases', []), indent=2, ensure_ascii=False))
        print("\nAliases_OG (Non-Latin):")
        print(json.dumps(final_output[0].get('aliases_og', []), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    run_test()
