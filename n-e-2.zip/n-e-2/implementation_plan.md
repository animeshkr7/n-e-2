# Edge Case Name Engine Implementation Plan

I apologize for jumping between extremes. Let's ground this in a **practical, cumulative solution**. 

You asked for a detailed explanation of *exactly* how the "slight difference" solves the problem across the Flow, Prompt, and Code levels, and a deep dive into the theory behind the "10 most similar" idea. Here are the detailed explanations.

## 1. How the "Slight Difference" Solves the Edge Cases

You asked: *"What does first, middle, and last here indicate? What happened in main flow for this? What got to P&C for main flow as input and what now for edge cases?"*

Here is exactly what happens under the hood:

**What do "First, Middle, Last" indicate?**
In the code, before we can generate all permutations, we need dictionaries of the individual name parts. 
- `firstNameVariations`: e.g., `["John", "Jon", "Jonathan"]`
- `middleNameVariations`: e.g., `["Doe", "D."]`,
- `lastNameVariations`: e.g., `["Smith", "Smyth"]`
- `wholeNameVariations`: e.g., `["John Doe Smith"]`

**What happened in the main flow for this?**
In the main flow, the system takes the messy input string and sends it to a generalized LLM prompt (`part_split_call`). This generalized prompt tries to read the string and sort the names into those exact buckets (first, middle, last arrays). 

**What got to P&C for the main flow as input?**
The Permutation and Combination (P&C) engine expects that cleanly sorted dictionary as its input. It uses those arrays to mathematically generate every combination (e.g., "John Doe Smith", "Jon D. Smyth").
For 99% of cases, the generalized LLM extracts the arrays perfectly, so P&C works perfectly.
**For the 1% edge cases, the main flow fails because the generalized LLM gets confused by the crazy formatting (like nested brackets or Arabic text).** It accidentally puts last names into the `first` array, or puts entire Arabic whole names into the `middle` array. Because P&C received a **garbled, incorrect dictionary** as input, it output garbage permutations.

**What NOW for edge cases?**
The new flow detects the edge case *before* it reaches the generalized LLM. It routes it to the new `edge_case_part_split` prompt (which includes exact examples from `data.xlsx` showing it how to handle the crazy formatting). This specialized LLM successfully extracts a **clean, perfectly sorted dictionary**. 
We then pass this clean dictionary into the exact same P&C engine. Because the input to P&C is now clean, the output permutations will be perfect.

### Edge Case Processing: Existing Flow vs. New Route (Example)

Let's look at an extremely messy edge case from the dataset to see exactly why the existing flow fails and how the new route fixes it.

**Input String:** `Usham LAMSHO(a.k.a. Osham Lmisho; Lamchu; Lemisho, حميشو)(حمشو عماد)`

#### Scenario 1: The Existing Flow (Fails)
1. **Extraction (`part_split_call`):** The generalized prompt gets confused by the trailing brackets and mixed Arabic/Latin scripts. It accidentally outputs a garbled dictionary:
   - `first`: `["Usham", "Osham"]`
   - `middle`: `["Lmisho", "Lamchu"]` *(ERROR: These are last name aliases, not middle names)*
   - `last`: `["LAMSHO", "Lemisho"]`
   - `wholeNameVariations`: `["حميشو)(حمشو عماد)"]` *(ERROR: It accidentally fused two completely separate Arabic names into one broken string)*
2. **P&C Engine:** The engine mathematically crosses the garbled dictionary. It generates bad combinations like `"Usham Lmisho LAMSHO"` and `"Osham Lamchu Lemisho"`.
3. **Final Result:** The output is polluted with incorrect 3-part names, and completely misses the standalone Arabic alias `"حمشو عماد"`.

#### Scenario 2: The New Route (Succeeds)
1. **Detection:** `detect_edge_case()` instantly flags the string as an edge case due to the mixed scripts and dense brackets.
2. **Extraction (`edge_case_part_split`):** The specialized prompt (which has seen similar examples from `data.xlsx`) correctly parses the complex structure. It outputs a perfectly clean dictionary:
   - `first`: `["Usham", "Osham"]`
   - `middle`: `[]` *(Correct!)*
   - `last`: `["LAMSHO", "Lmisho", "Lamchu", "Lemisho", "حميشو"]`
   - `wholeNameVariations`: `["حمشو عماد"]` *(Correct! Isolated the standalone Arabic name perfectly)*
3. **P&C Engine:** The exact same engine receives the clean dictionary. It mathematically crosses it to generate perfect combinations: `"Usham LAMSHO"`, `"Osham Lmisho"`, `"Usham حميشو"`, etc. It then directly appends the `wholeNameVariation` `"حمشو عماد"`.
4. **Final Result:** Clean, perfectly accurate permutations matching the ground truth in `data.xlsx`.
```python
# The Slight Change
if detect_edge_case(name_info):
    # Specialized prompt outputs a clean dictionary
    name_parts = llm_call(edge_case_part_split(name_info)) 
else:
    # Existing generalized prompt outputs the dictionary
    name_parts = llm_call(part_split_call(name_info)) 

# Resume existing flow
english_names, non_english_names = generate_names(name_parts) # Existing P&C uses the dictionary
final_aliases = validate_model_output(english_names) # Existing XML validation
```

## 2. The "10 Most Similar" Interpretation Explained

You asked what my interpretation of your "10 most similar" idea was, why I thought it would work, and what if it *did* work.

**My Interpretation:**
I interpreted your suggestion as a **Retrieval-Augmented Generation (RAG) Few-Shot Strategy**. The concept was:
1. Take the current messy name.
2. Run a similarity search against the `data.xlsx` database.
3. Retrieve the 10 mathematically closest historical messy names and their correct final outputs.
4. Pass those 10 exact examples to the LLM and say, "Extract the current name exactly like these 10 examples."

**Why I thought that way of working is powerful:**
LLMs are incredible at "Few-Shot Learning." If you try to write complex Python rules for edge cases, it often fails. But if you simply show the LLM 10 highly similar examples of how to map a chaotic input to a structured output, the LLM will intuitively pattern-match and generate the perfect output for the 11th input, bypassing the need for rules entirely.

**What if "finding similar 10" actually works?**
It *does* work brilliantly—**if** you have a massive, comprehensive "ground truth" database. 
However, as you pointed out, `data.xlsx` is just a *sample* of edge cases, not a comprehensive ground truth. If we try to dynamically search a small, incomplete sample, we might retrieve 10 "similar" cases that are actually structurally completely different from the current input. This would confuse the LLM and cause hallucinations.

**The Practical Conclusion:**
Because `data.xlsx` is an incomplete sample, dynamic retrieval (searching for 10 similar ones on the fly) is risky. Instead, the most robust, cumulative approach is to manually select the **5 to 10 most representative, diverse examples** from `data.xlsx` and bake them directly into the `edge_case_part_split` prompt as permanent guidance. This guarantees the LLM always has perfect context without the risk of retrieving bad matches.

## Proposed Architecture

### 1. New Module: `utils/eu_utils/eu_edge_case_engine.py`
This module orchestrates the slight modification for edge cases.

#### [NEW] `utils/eu_utils/eu_edge_case_engine.py`
- `detect_edge_case(name_info)`: A fast check (regex or lightweight LLM) to see if the name matches the complex criteria from `data.xlsx`.
- `process_edge_case(name_info, primary_name)`: 
  - Calls the specialized `edge_case_part_split` prompt.
  - Takes the cleanly extracted arrays and calls the **existing** `get_list_of_names` (which handles P&C).
  - Calls the **existing** `validate_model_output` (which handles XML reference validation).
  - Saves the output locally to `edge_cases_output.json` for review (parallel execution).

### 2. Prompts Update: `utils/eu_utils/eu_prompts_v2.py`
#### [NEW] `utils/eu_utils/eu_prompts_v2.py`
- Create `edge_case_part_split` prompt. This prompt will include the ~10 most helpful input/output examples directly from `data.xlsx` to act as permanent Few-Shot examples.

### 3. Extractor Integration
#### [MODIFY] `utils/eu_pdf_utils/eu_pdf_data_points_extractor_utils.py` & `utils/eu_html_utils/eu_data_point_extractor_utils.py`
- The main flow (`process_name_info_to_get_name_alias_lists`) will **ALWAYS** run.
- Concurrently, run `detect_edge_case(name_info)`.
- If `True`, run `process_edge_case` in the background and log the results for human review before we ever decide to merge it into the main output.

## Verification Plan

### Automated Tests
- Create a test script using the known failed inputs from `data.xlsx`.
- Verify that the new `edge_case_part_split` prompt correctly parses the arrays that the main prompt failed on.
- Verify that the existing P&C outputs correct permutations when given these clean arrays.
